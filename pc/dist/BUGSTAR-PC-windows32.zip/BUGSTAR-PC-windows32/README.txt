BUGSTAR for PC
Run BUGSTAR (Linux) or BUGSTAR.exe (Windows). Everything needed is in this folder.
KEYS: arrows/WASD move, X or Space = A, Z or K = B, Backspace/Tab = Select, Enter = Start, E = R, Q = L.
Stormclock Coil = Q + E together. Gamepad works (A/B, Back, Start, shoulders, stick, d-pad).
Esc (or Back+Start on a pad) = options: video, audio, rebind keys and pad. F11 fullscreen, F12 screenshot, F3 fps.
PC LAB: pause, WORLD page, then B. Saves, settings and screenshots go in the "data" folder next to the game (portable.txt makes this happen). Delete portable.txt to use %APPDATA%\BUGSTAR instead. Keep the whole folder together.
Options: --fullscreen --windowed --size W H --scale-mode 0|1 --no-vsync --no-audio
NOTE: this Windows build was cross-compiled only; it has NOT been run by the builder (no Windows or Wine here). Please report problems.
Mouse: click = A, right click = B, wheel = up/down; the options screen (Esc) answers the mouse. Options: 3D VIEWS (AUTO/NATIVE/CLASSIC), ACCESSIBILITY (menu text size, high contrast, mouse).
Kart race ground now draws in the PC build, smooth at window size (NATIVE) or the GBA look (CLASSIC). Dungeon, planet and space views still draw at the game's own resolution.
