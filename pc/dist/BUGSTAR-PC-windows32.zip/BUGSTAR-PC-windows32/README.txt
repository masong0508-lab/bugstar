BUGSTAR for PC
Run BUGSTAR (Linux) or BUGSTAR.exe (Windows). Everything needed is in this folder. Keep the whole folder together.
KEYS: arrows/WASD move, X or Space = A, Z or K = B, Backspace/Tab = Select, Enter = Start, E = R, Q = L.
Stormclock Coil = Q + E together. Gamepad works (A/B, Back = Select, Start, shoulders, stick, d-pad). Mouse: click = A, right click = B, wheel = up/down.
Esc (or Back+Start on a pad) = options: video, audio, rebind keys and pad, 3D views, accessibility, side game difficulty. F11 fullscreen, F12 screenshot, F3 fps.
PC LAB: pause, WORLD page, then B.
SAVES: saves, settings and screenshots go in the "data" folder next to the game (portable.txt makes this happen). Delete portable.txt to use the per-user folder (%APPDATA%\BUGSTAR on Windows, ~/.local/share/BUGSTAR on Linux) instead.
Command line: --fullscreen --windowed --size W H --scale-mode 0|1 --no-vsync --no-audio
3D views: kart race, dungeon draw smooth at window size (NATIVE) or in the GBA look (CLASSIC); planet and space views use the game's own resolution for now.
NOTE: the Windows build was cross-compiled only; it has NOT been run on real Windows by the builder. Please report problems.

IF IT WON'T OPEN: this version shows an error box with the reason and writes bugstar_log.txt next to BUGSTAR.exe. Send me that text.
Extract the whole zip first (do not run it from inside the zip). If Windows says "protected your PC": More info > Run anyway.
